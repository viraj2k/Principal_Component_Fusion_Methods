function plotedgelist1(elist, figno, linestyle)

    figure(figno);
    for e = 1:length(elist)
       line(elist{e}(:,2), elist{e}(:,1), 'LineStyle', linestyle, ...
	    'LineWidth',1);
    end