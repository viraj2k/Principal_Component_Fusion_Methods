% function Y = fuse_pca(M1, M2)
%Y = fuse_pca(M1, M2) image fusion with PCA method
%
%    M1 - input image #1
%    M2 - input image #2
%
%    Y  - fused image   

%    (Oliver Rockinger 16.08.99)

% check inputs 
clc;
clear all;
%Y=fusefile(M1,M2) image fusion with iterative fuzzy logic method
im1 = imread('F:\matlab codes\images\med9\med9.bmp');
im2=imread('F:\matlab codes\images\med9\med93.bmp');
M1=hmf(im2,[5 5]);
M2=adaweightmedian(im2);
im3=im2(1:130,1:130);
im4=im2(1:130,131:260);
im5=im2(131:260,1:130);
im6=im2(131:260,131:260);
M31=hmf(im3,[5 5]);
M32=adaweightmedian(im3);
M41=hmf(im4,[5 5]);
M42=adaweightmedian(im4);
M51=hmf(im5,[5 5]);
M52=adaweightmedian(im5);
M61=hmf(im6,[5 5]);
M62=adaweightmedian(im6);
[y3 a3]=fuse_pca(double(M31),double(M32));
[y4 a4]=fuse_pca(double(M41),double(M42));
[y5 a5]=fuse_pca(double(M51),double(M52));
[y6 a6]=fuse_pca(double(M61),double(M62));
% Y=[y3 y4;y5 y6];
a=[(a3(1)+a4(1)+a5(1)+a6(1))/4;(a3(2)+a4(2)+a5(2)+a6(2))/4];
% [z1 s1] = size(M1);
% [z2 s2] = size(M2);
% if (z1 ~= z2) | (s1 ~= s2)
%   error('Input images are not of same size');
% end;
% 
% % compute, select & normalize eigenvalues 
% [V, D] = eig(cov([double(M1(:)) double(M2(:))]));
% % if (D(1,1) > D(2,2))
%   a = V(:,1)./sum(V(:,1));
% % else  
%   a = V(:,2)./sum(V(:,2));
% % end;
% 
% % and fuse
Y = a(1)*M1+a(2)*M2;
imshow(mat2gray(Y))
% [p1 m1]=psnrmse(im1,im2);
% % [p2 m2]=psnrmse(im1,M1);
% % [p3 m3]=psnrmse(im1,M2);
[p4 m4]=psnrmse(double(im1),Y);

