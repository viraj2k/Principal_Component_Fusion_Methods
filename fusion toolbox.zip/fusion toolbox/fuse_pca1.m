% function Y = fuse_pca(M1, M2)
%Y = fuse_pca(M1, M2) image fusion with PCA method
%
%    M1 - input image #1
%    M2 - input image #2
%
%    Y  - fused image   

%    (Oliver Rockinger 16.08.99)

% check inputs 
clc;
clear all;
%Y=fusefile(M1,M2) image fusion with iterative fuzzy logic method
im1 = imread('F:\matlab codes\images\med9\med9.bmp');
im2=imread('F:\matlab codes\images\med9\med93.bmp');
M1=hmf(im2,[5 5]);
M2=adaweightmedian(im2);
% M1=imread('D:\SSK\pca-wt\images\med1.jpg');
% % M1=rgb2gray(M1);
% M1=im2double(M1);
% % M1=imresize(M1,[248,376],'nearest');
% imshow(M1);
% pause
% M2=imread('D:\SSK\pca-wt\images\med2.jpg');
% % M2=rgb2gray(M2);
% M2=im2double(M2);
% imshow(M2);
% pause
[z1 s1] = size(M1);
[z2 s2] = size(M2);
if (z1 ~= z2) | (s1 ~= s2)
  error('Input images are not of same size');
end;
x=M1;y=M2;
% compute, select & normalize eigenvalues 
[V, D] = eig(cov([double(M1(:)) double(M2(:))]));
% if (D(1,1) > D(2,2))
  a = V(:,1)./sum(V(:,1));
% else  
  a = V(:,2)./sum(V(:,2));
% end;

% and fuse
Y = a(1)*M1+a(2)*M2;
imshow(mat2gray(Y))
[p1 m1]=psnrmse(im1,im2);
% [p2 m2]=psnrmse(im1,M1);
% [p3 m3]=psnrmse(im1,M2);
[p4 m4]=psnrmse(im1,Y);

