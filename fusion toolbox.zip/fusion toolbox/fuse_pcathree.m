function [y a] = fuse_pcathree(M1,M2,M3)
%Y = fuse_pca(M1, M2) image fusion with PCA method
%
% clc;clear all;
% M1 = double(rgb2gray(imread('F:\matlab codes\images\MRI BRAIN\7.jpg')));
% M2 = double(rgb2gray(imread('F:\matlab codes\images\MRI BRAIN\8.jpg')));
% M3 = double(rgb2gray(imread('F:\matlab codes\images\MRI BRAIN\9.jpg')));
%    M1 - input image #1
%    M2 - input image #2
%
%    Y  - fused image   

%    (Oliver Rockinger 16.08.99)

% check inputs 
[z1 s1] = size(M1);
[z2 s2] = size(M2);
if (z1 ~= z2) | (s1 ~= s2)
  error('Input images are not of same size');
end;

% compute, select & normalize eigenvalues 
[V, D] = eig(cov([M1(:) M2(:) M3(:)]));
if (D(1,1) > D(2,2)&& D(1,1) >D(3,3))
  a = V(:,1)./sum(V(:,1));
elseif (D(2,2) > D(1,1)&& D(2,2) >D(3,3))  
  a = V(:,2)./sum(V(:,2));
elseif (D(3,3) > D(1,1)&& D(3,3) >D(2,2))
    a = V(:,3)./sum(V(:,3));
end;

% and fuse
y = a(1)*M1+a(2)*M2+a(3)*M3;
