clc;
clear all;
M1=imread('F:\matlab codes\images\fusion\fuse1.jpg');
M2=imread('F:\matlab codes\images\fusion\fuse2.jpg');
M1=im2double(M1);
M2=im2double(M2);
[gra E1 M1T1]=fuse_graco(M1,M2,4,1,1);
[con E2 M1T2]=fuse_conco(M1,M2,4,1,1);
[fsd E3 M1T3]=fuse_fsdco(M1,M2,4,1,1);
[lap E4 M1T4]=fuse_lapco(M1,M2,4,1,1);
[rat E5 M1T5]=fuse_ratco(M1,M2,4,1,1);
[cA1,cH1,cV1,cD1] = dwt2(M1,'db1');
[cA2,cH2,cV2,cD2] = dwt2(M2,'db1');
nbcol=16;
cod_X = wcodemat(M1,nbcol); 
cod_cA1 = wcodemat(cA1,nbcol); 
cod_cH1 = wcodemat(cH1,nbcol); 
cod_cV1 = wcodemat(cV1,nbcol); 
cod_cD1 = wcodemat(cD1,nbcol); 
dec2d = [... 
        cod_cA1,     cod_cH1;     ... 
        cod_cV1,     cod_cD1      ... 
        ];