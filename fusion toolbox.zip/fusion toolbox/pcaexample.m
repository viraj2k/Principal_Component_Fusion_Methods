% function Y = fuse_pca(M1, M2)
%Y = fuse_pca(M1, M2) image fusion with PCA method
%
%    M1 - input image #1
%    M2 - input image #2
%
%    Y  - fused image   

%    (Oliver Rockinger 16.08.99)

% check inputs 
clc;
clear all;
M1=imread('F:\matlab codes\images\fusion\fuse1.jpg');
M2=imread('F:\matlab codes\images\fusion\fuse2.jpg');
% M1=imread('F:\matlab codes\images\fusion\clockA.jpg');
% M2=imread('F:\matlab codes\images\fusion\clockB.jpg');
% M1=imread('F:\matlab codes\images\fusion\naviA.jpg');
% M2=imread('F:\matlab codes\images\fusion\naviB.jpg');
% M1=imread('F:\matlab codes\images\fusion\remoteA.jpg');
% M2=imread('F:\matlab codes\images\fusion\remoteB.jpg');
% M1=imread('F:\matlab codes\images\fusion\airport1.jpg');
% M2=imread('F:\matlab codes\images\fusion\airport2.jpg');
% M1=imread('F:\matlab codes\images\fusion\boat1.jpg');
% M2=imread('F:\matlab codes\images\fusion\boat2.jpg');
% M1=imresize(M1,[256 256]);
% M2=imresize(M2,[256 256]);
[z1 s1] = size(M1);
[z2 s2] = size(M2);
if (z1 ~= z2) | (s1 ~= s2)
  error('Input images are not of same size');
end;

% compute, select & normalize eigenvalues 
[V, D] = eig(cov([double(M1(:)) double(M2(:))]));
% if (D(1,1) > D(2,2))
  a = V(:,1)./sum(V(:,1));
% else  
  a = V(:,2)./sum(V(:,2));
% end;

% and fuse
Y = a(1)*M1+a(2)*M2;
imshow(M1);
figure,imshow(M2);
figure,imshow(mat2gray(Y))
% [p1 m1]=psnrmse(im1,im2);
% % [p2 m2]=psnrmse(im1,M1);
% % [p3 m3]=psnrmse(im1,M2);
% [p4 m4]=psnrmse(im1,Y);

