clc;clear all; 
a=[1 2; 
   3 6];
b=[8 9;
   12 11];
x=[a(:) b(:)];
a1=mean(a(:));
b1=mean(b(:));
a2=a(:)-a1;
b2=b(:)-b1;
x2=[a2 b2];
covar=cov(x);
[v d]=eig(covar);
plot(d,'o','MarkerSize',6)