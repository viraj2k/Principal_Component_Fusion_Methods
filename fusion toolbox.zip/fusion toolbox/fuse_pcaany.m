function [y1 a1] = fuse_pcaany(ca,n)
% clc;clear all;
% n=input('Number of images for fusion');
% for i=1:1:n;
% %     a{i} = imread('F:\matlab codes\images\fusion\atlvct5s.jpg');
% % b = imread('F:\matlab codes\images\fusion\atlvct6s.jpg');
% % c = imread('F:\matlab codes\images\fusion\atlvct7s.jpg');
%     [imagefile1 , pathname]= uigetfile('*.jpg;','Open file Eye image');
%     name=[pathname,imagefile1];
%     if imagefile1 ~= 0
%         a{i} = rgb2gray(imread([name]));
%         [ca{i},ch{i},cv{i},cd{i}] = dwt2(a{i},'db3');
%     end;
% % %     [ca{i},ch{i},cv{i},cd{i}] = dwt2(a{i},'db3');
% end
for i=1:1:n
    M(:,i)=ca{i}(:);
end 
[V, D] = eig(cov(M));
[z1 s1] = size(D);
for i=1:1:s1
    D1(i)=D(i,i);
end 
D2=max(D1(i));
for i=1:1:s1
    if D1(i)==D2;
        a1 = V(:,i)./sum(V(:,i));
    end
end
[z2 s2]=size(ca{1});
% and fuse
y1=zeros(z2,s2);
for i=1:1:n
    y = a1(i)*ca{i};
    y1=y1+y;
end 
% end
