% function [y a] = corrpca(M1, M2)
clc; clear all;
a = imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\ct5\ct5.bmp');
b = imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\ct6\ct6.bmp');
% a = imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\mr1\mr1.bmp');
% b = imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\mr2\mr2.bmp');
% a = imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\mr3\mr3.bmp');
% b = imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\mr4\mr4.bmp');
% a = imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\mr5\mr5.bmp');
% b = imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\mr6\mr6.bmp');
% a = imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\mr7\mr7.bmp');
% b = imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\mr8\mr8.bmp');
% a = rgb2gray(imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\mr9\mr9.bmp'));
% b = rgb2gray(imread('F:\matlab codes\CODES\MEDIAN FILTER ALG\LPCAFCM\medical images\mr10\mr10.bmp'));
M1=double(a);
M2=double(b);

%Y = fuse_pca(M1, M2) image fusion with PCA method
%
%    M1 - input image #1
%    M2 - input image #2
%
%    Y  - fused image   

%    (Oliver Rockinger 16.08.99)

% check inputs 
[z1 s1] = size(M1);
[z2 s2] = size(M2);
if (z1 ~= z2) | (s1 ~= s2)
  error('Input images are not of same size');
end;

% compute, select & normalize eigenvalues 
% convolu=cov([M1(:) M2(:)]);
% [V, D] = eig(convolu);
correla=xcorr([M1(:) M2(:)]);
[V, D] = eig(correla);
if (D(1,1) > D(2,2))
  a = V(:,1)./sum(V(:,1));
else  
  a = V(:,2)./sum(V(:,2));
end;

% and fuse
y = a(1)*M1+a(2)*M2;
